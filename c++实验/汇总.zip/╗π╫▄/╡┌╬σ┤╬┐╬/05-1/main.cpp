#include "matrix.h"

using namespace std;

int main()
{
	Matrix m;
	m.Matrix_Input();
	m.Matrix_Show();
	m.Matrix_Multiply();
	m.Matrix_Transpose();
	m.Matrix_Rotate();

	return 0;
}
