#include "matrix.h"

void Matrix::Matrix_Input()
{
	cout << "请输入矩阵的行数（d1）: ";
	cin >> d1;
	
	cout << "请输入矩阵的列数（d2）: ";
	cin >> d2;
	
	cout << "请输入矩阵：" << endl;
	for (int i = 0; i < d1; i++) 
	{
		for (int j = 0; j < d2; j++) 
		{
			cin >> matrix[i][j];
		}
	}
}

void Matrix::Matrix_Show()
{
	cout << "现矩阵为：" << endl;
	for (int i = 0; i < d1; i++) 
	{
		for (int j = 0; j < d2; j++) 
		{
			cout << matrix[i][j] << " ";
		}
		cout << endl;
	}
}

void Matrix::Matrix_Multiply()
{
	cout << "你想对矩阵数乘吗(Y/N)：" << endl;
	char c;
	cin >> c;
	if (tolower(c) == 'n') return;
	else if (tolower(c) == 'y')
	{
		char flag = 'y';
		while(tolower(flag) == 'y')
		{
			cout << "输入数乘的标量：" << endl;
			int scalar;
			cin >> scalar;
			cout << "数乘后的矩阵为：" << endl;
			for (int i = 0; i < d1; i++)
			{
				for (int j = 0; j < d2; j++)
				{
					matrix[i][j] *= scalar;
					cout << matrix[i][j] << " ";
				}
				cout << endl;
			}
			cout << "你想继续对矩阵数乘吗(Y/N)" << endl;
			cin >> flag;
		}
	
	}
	else cout << "输入错误！" << endl;
}

void Matrix::Matrix_Transpose()
{
	cout << "你想对矩阵逆置吗(Y/N)：" << endl;
	char c;
	cin >> c;
	if (tolower(c) == 'n') return;
	else if (tolower(c) == 'y')
	{
		cout << "逆置后的矩阵为：" << endl;
		for (int j = 0; j < d2; j++)
		{
			for (int i = 0; i < d1; i++)
			{
				cout << matrix[i][j] << " ";
			}
			cout << endl;
		}
	}
	else cout << "输入错误！" << endl;
}

void Matrix::Matrix_Rotate()
{
	cout << "你想对矩阵旋转吗(Y/N)：" << endl;
	char c;
	cin >> c;
	if (tolower(c) == 'n') return;
	else if (tolower(c) == 'y')
	{
		char flag = 'y';
		while (tolower(flag) == 'y')
		{
			cout << "输入旋转的角度(90/180/270)：" << endl;
			int rotating;
			cin >> rotating;
			switch (rotating)
			{
				case 90:
				{
					cout << "旋转90度后的矩阵为：" << endl;
					for (int j = 0; j < d2; j++)
					{
						for (int i = d1 - 1; i >= 0; i--)
						{
							cout << matrix[i][j] << " ";
						}
						cout << endl;
					}
					break;
				}
				case 180:
				{
					cout << "旋转180度后的矩阵为：" << endl;
					for (int i = d1 - 1; i >= 0; i--)
					{
						for (int j = d2 - 1; j >= 0; j--)
						{
							cout << matrix[i][j] << " ";
						}
						cout << endl;
					}
					break;
				}
				case 270:
				{
					cout << "旋转270度后的矩阵为：" << endl;
					for (int j = d2 - 1; j >= 0; j--)
					{
						for (int i = 0; i < d1; i++)
						{
							cout << matrix[i][j] << " ";
						}
						cout << endl;
					}
					break;
				}
				default:
				{
					cout << "角度输入错误！" << endl;
				}
			}
			cout << "你想继续旋转吗(Y/N)：" << endl;
			cin >>flag;
		}
		
	}
	else cout << "输入错误！" << endl;
}
