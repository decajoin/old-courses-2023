#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>
#include <ctype.h>
using namespace std;
class Matrix
{
	int d1, d2, matrix[100][100];
public:
	Matrix(){}
	//Matrix(int,int,int tempmatrix[][100]);
	void Matrix_Input();
	void Matrix_Show();
	void Matrix_Multiply();
	void Matrix_Transpose();
	void Matrix_Rotate();
};


#endif
