#include "calculator.h"

using namespace std;

int main()
{
	double x, y;
	char a;
	cout << "输入操作数1：" ;
	cin  >> x;
	cout << "输入操作数2：" ;
	cin  >> y;
	cout << "输入操作符：" ;
	cin  >> a;
	
	calculator j(x, y, a);
	cout << x << " " << a << " " << y << " = " << j.operators(x, y, a) << endl;
	
	cout << "是否再进行操作(Y/N)：";
	char flag = 'y';
	cin >> flag;
	double k = j.operators(x, y, a);
	while (tolower(flag) == 'y')
	{
		cout << "输入新的操作数：";
		cin >> x;
		cout << "输入新的操作符：";
		cin >> a;
		cout << k << " " << a << " " << x << " = " << j.operators(k, x, a) << endl;
		k = j.operators(k, x, a);
		cout << "是否再进行操作(Y/N)：";
		cin >> flag;
	}
	cout << "已经退出计算器" << endl;
	
	return 0;
}
