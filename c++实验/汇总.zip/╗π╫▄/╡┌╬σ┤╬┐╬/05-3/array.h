#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>

using namespace std;

const int MAXN = 10;
class Array
{
	int length;
	int data[MAXN];
public:
	Array() {length = 0;}
	Array(int a[], int n);
	int Length();
	void Display();
	void Insert(int x);
	void Delete(int x);
	int Search(int l, int r, int x);
	void Sort(int l, int r);
};

#endif
