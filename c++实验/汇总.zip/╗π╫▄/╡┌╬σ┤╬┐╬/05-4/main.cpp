#include <iostream>
#include <string>
using namespace std;

class Singer {
private:
	string name;
	string gender;
	int age;
	string song;
	
public:
	// 一个类的构造函数，它在对象创建时自动调用
	Singer() {
		cout << "提示信息：调用Singer构造函数!" << endl;
		age = 0; // 初始化年龄为0
	}
	
	// 一个类的析构函数，它在对象被销毁时自动调用
	~Singer() {
		cout << "提示信息：调用Singer析构函数!" << endl;
	}
	
	// 报名函数
	void Enroll() {
		cout << "请输入歌手的姓名: ";
		cin >> name;
		cout << "请输入歌手的性别: ";
		cin >> gender;
		cout << "请输入歌手的年龄: ";
		cin >> age;
		cout << "请输入歌手演唱的曲目: ";
		cin >> song;
	}
	
	// 显示歌手信息
	void Display() {
		cout << "歌手信息如下所示：" << endl;
		cout << "姓名: " << name << endl;
		cout << "性别: " << gender << endl;
		cout << "年龄: " << age << endl;
		cout << "演唱曲目: " << song << endl;
	}
	
	// 修改歌手信息的成员函数
	void Modify() {
		int choose;
		cout << "1.姓名  2.性别  3.年龄  4.演唱曲目" << endl;
		cout << "请选择需要修改的选项：";
		cin >> choose;
		
		switch (choose) {
		case 1:
			cout << "请输入新的姓名: ";
			cin >> name;
			break;
		case 2:
			cout << "请输入新的性别: ";
			cin >> gender;
			break;
		case 3:
			cout << "请输入新的年龄: ";
			cin >> age;
			break;
		case 4:
			cout << "请输入新的演唱曲目: ";
			cin >> song;
			break;
		default:
			cout << "无效的选项！" << endl;
		}
		cout << "歌手信息修改成功！" << endl;
	}
};

int main() {
	const int NUM = 3; // 歌手数组大小
	Singer s[NUM];
	char flag1 = 'y', flag2 = 'y';
	
	while (tolower(flag1) == 'y') {
		cout << "*************************************************************************" << endl;
		cout << "请输入这次报名歌手的数量（<=3）：";
		int num;
		cin >> num;
		
		if (num > NUM) {
			cout << "报名歌手数量超过了数组大小，请重新输入。" << endl;
			continue;
		}
		
		for (int i = 0; i < num; i++) {
			s[i].Enroll();
		}
		
		cout << "报名歌手的信息如下所示：" << endl;
		for (int i = 0; i < num; i++) {
			s[i].Display();
		}
		
		cout << "是否需要修改报名歌手的信息(Y/N)：";
		cin >> flag2;
		if (tolower(flag2) == 'y') {
			cout << "请输入需要修改的歌手信息序号：";
			int seq;
			cin >> seq;
			
			if (seq >= 1 && seq <= num) {
				s[seq - 1].Modify();
				cout << "修改后的歌手信息如下所示：" << endl;
				s[seq - 1].Display();
			} else {
				cout << "无效的歌手序号！" << endl;
			}
		}
		
		cout << "是否继续输入报名歌手的信息?(Y/N) ";
		cin >> flag1;
	}
	
	return 0;
}

