#include "point.h"

// 友元函数
double ExternalDistance(const Point &p1, const Point &p2)
{
	double dx = p1.x - p2.x;
	double dy = p1.y - p2.y;
	return sqrt(dx * dx + dy * dy);
}

// 友元成员函数
double Distance::MemberDistance(const Point &p1, const Point &p2)
{
	double dx = p1.x - p2.x;
	double dy = p1.y - p2.y;
	return sqrt(dx * dx + dy * dy);
}

// 友元类实现
double Distance::CaculateDis(const Point &p1, const Point &p2)
{
	double dx = p1.x - p2.x;
	double dy = p1.y - p2.y;
	return sqrt(dx * dx + dy * dy);
}
