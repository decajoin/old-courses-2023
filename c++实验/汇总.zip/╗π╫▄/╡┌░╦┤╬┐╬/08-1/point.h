#include <iostream>
#include <cmath>
using namespace std;

class Point;

class Distance
{
public:
	// 友元成员函数
	double MemberDistance(const Point &p1, const Point &p2);
	// 友元类实现
	double CaculateDis(const Point &p1, const Point &p2);
};


class Point
{
public:
	Point(){}
	Point(double tempx, double tempy):x(tempx), y(tempy){}
	// 友元函数
	friend double ExternalDistance(const Point &p1, const Point &p2);
	// 友元成员函数
	friend double Distance::MemberDistance(const Point &p1, const Point &p2);
	// 友元类
	friend class Distance;
private:
	double x, y;
};



