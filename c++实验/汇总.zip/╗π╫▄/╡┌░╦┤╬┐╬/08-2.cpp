#include <iostream>
#include <string>
using namespace std;

class Course {
	int cno;
	string cname;
	
public:
	
	Course(int tempcno, string tempcname) : cno(tempcno), cname(tempcname) {}
	
	friend class Student; // 声明Student类为Course类的友元
};

class Score {
	int score;
	
public:
	Score(int tempscore) : score(tempscore) {}
	
	void score_show() {
		cout << "分数: " << score << endl;
	}
	
	friend class Student; // 声明Student类为Score类的友元
};

class Student {
	int sno;
	string sname, gender, grade;
	Course sc;
	Score ss;
	
public:
	Student(int tempsno, string tempsname, string tempgender, string tempgrade, Course tempsc, Score tempss)
	: sno(tempsno), sname(tempsname), gender(tempgender), grade(tempgrade), sc(tempsc), ss(tempss) {}
	
	void student_show() {
		cout << "学号: " << sno << endl;
		cout << "姓名: " << sname << endl;
		cout << "性别: " << gender << endl;
		cout << "班级: " << grade << endl;
		cout << "课程信息: " << sc.cno << " " << sc.cname << endl;
		ss.score_show();
	}
};

int main() {
	Course cs1(1, "C++");
	Score sc1(90);
	Student st1(201811219, "张三", "男", "计科161", cs1, sc1);
	st1.student_show();
	
	return 0;
}

