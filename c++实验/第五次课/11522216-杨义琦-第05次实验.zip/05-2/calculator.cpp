#include "calculator.h"

double cal_plus(double x, double y)
{
	return x + y;
}

double cal_minus(double x, double y)
{
	return x - y;
}

double cal_multiply(double x, double y)
{
	return x * y;
}

double cal_divide(double x, double y)
{
	return (x * 1.0) / y;
}


double calculator::operators(double a1,double a2,char a3)
{
	switch (a3)
	{
		case '+':
		{
			return cal_plus(a1, a2);
			break;
		}
		case '-':
		{
			return cal_minus(a1, a2);
			break;
		}
		case '*':
		{
			return cal_multiply(a1, a2);
			break;
		}
		case '/':
		{
			return cal_divide(a1, a2);
			break;
		}
		default:
		{
			cout << "操作符输入错误！" << endl;
		}

	}

}
