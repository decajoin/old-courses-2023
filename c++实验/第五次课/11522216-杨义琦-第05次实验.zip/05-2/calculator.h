#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <iostream>
#include <cctype>

using namespace std;
class calculator
{
	double k1, k2, answer;
	char k3;
	
	public:
		calculator(double x, double y, char z) {k1=x;k2=y;k3=z;}
		double operators(double a1,double a2,char a3);
};


#endif
