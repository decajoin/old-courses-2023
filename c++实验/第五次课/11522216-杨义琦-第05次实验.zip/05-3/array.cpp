#include "array.h"



Array::Array(int a[], int n)
{
	cout<<"调用构造函数初始化数组！"<<endl;
	int i;  length=n;
	for(i=0;i<n;i++)  data[i]=a[i];
}

int Array::Length()
{
	return length;
}

void Array::Display()
{
	cout << "显示数组元素：";
	for (int i = 0; i < length; i++)
	{
		cout << data[i] << " ";
	}
	cout << endl;
}

void Array::Insert(int x)
{
	if (length >= 10) 
	{
		cout << "插入失败！"  << endl;
		return;
	}
	
	for (int i = 0; i < length; i++)
	{
		if (data[i] > x)
		{
			for (int j = length - 1; j >= i; j--)
			{
				data[j + 1] = data[j];
			}
			data[i] = x;
			length++;
			return;
		}
	}
}

void Array::Delete(int x)
{
	if (length == 0)
	{
		cout << "删除失败！" << endl;
		return;
	}
	
	for (int i = 0; i < length; i++)
	{
		if (data[i] == x)
		{
			for (int j = i; j < length - 1; j++)
			{
				data[j] = data[j + 1];
			}
			length--;
			return;
		}
	}
	
	cout << "要删除的值不存在！" << endl;
	return;
}


void swap(int &a, int &b)
{
	int temp = a;
	a = b;
	b = temp;
}


void Array::Sort(int l, int r)
{
	if (l >= r) return;
	
	int x = data[(l + r) >> 1];
	int i = l - 1, j = r + 1;
	while (i < j)
	{
		do i++; while (data[i] < x);
		do j--; while (data[j] > x);
		if (i < j) swap(data[i], data[j]);	
	}
	
	Sort(l, j);
	Sort(j + 1, r);
}


// 二分查找
int Array::Search(int l, int r, int x)
{
	int mid = (l + r) >> 1;
	if (x == data[mid]) return mid;
	
	if (l >= r) return -1;
	
	if (x < data[mid])
	{
		Search(l, mid - 1, x);
	}
	else
	{
		Search(mid + 1, r, x);
	}
}





