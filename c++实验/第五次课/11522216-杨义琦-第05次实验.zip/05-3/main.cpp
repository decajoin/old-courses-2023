#include "array.h"

using namespace std;

int main()
{
	int i, n, olda[10], choose, x, y, z, location;
	cout << "请输入数组的长度(n < 10)：";
	cin >> n;
	cout << "请依次输入数组的元素：";
	for(i=0;i<n;i++){ cin>>olda[i]; }
	Array newa(olda,n);
	while(1)
	{
		cout<<"****************************************************"<<endl;
		cout<<"** 1.显示  2.排序  3.插入  4.删除  5.查找  6.退出 **"<<endl;
		cout<<"****************************************************"<<endl;
		cout<<"请选择操作项：";
		cin>>choose;
		switch(choose){
		case 1:
			newa.Display();  break;
		case 2:
			newa.Sort(0, newa.Length() - 1);  break;
		case 3:
			cout<<"请输入需要插入的数字：";
			cin>>x;
			newa.Insert(x);  break;
		case 4:
			cout<<"请输入需要删除的数字：";
			cin>>y;
			newa.Delete(y);  break;
		case 5:
			cout<<"请输入需要查找的数字：";
			cin>>z;
			location=newa.Search(0, newa.Length() - 1, z);
			if(location!=-1){cout<<"此数字位置是："<<location<<endl;}
			else {cout<<"查找失败！！"<<endl;}
			break;
		case 6:
			exit(1);
			break;
		default:
			cout<<"选择数字有误，请重新选择：";
			break;
		}
	}		
}

